ROTATION VERSION ARCHIVE

Keep this archive somewhere safe. Each ZIP in the releases folder is a standalone historical build.

If a future version breaks, open an older ZIP and you can go back immediately.
