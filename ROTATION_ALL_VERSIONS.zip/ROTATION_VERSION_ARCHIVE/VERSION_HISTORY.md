# ROTATION - Version Archive

This folder preserves every packaged ROTATION game build created so far.

## Releases

### v0.1
First playable browser prototype.

### v0.2
PvE-focused build with AI opponent, notebook-inspired cards, move tooltips, pixel-art portrait placeholders, lane-by-lane combat, and first-pass move VFX.

### v0.3
Card presentation and VFX revision. Added move-specific corner emblems, improved notebook-style card layout, symbol/VFX workshop, revised attack presentation, and support for custom uploaded character art.

## Rule for future builds
Never overwrite an older release ZIP. Every meaningful build should be saved as a new version (for example v0.3.1, v0.4, v0.5) and added to this archive.
